# Super Mario

> Super Mario is a platformer game developed and published by Nintendo for the NES game console. Players control Mario as they traverse the Mushroom Kingdom to rescue Princess Peach from Bowser. They traverse side-scrolling stages while avoiding hazards such as enemies and pits with the aid of power-ups such as the Super Mushroom, Fire Flower, and Starman.
